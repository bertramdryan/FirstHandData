A few notes:
For this project, for the purpose of evaluating one's ability to write code.


Requirements:
Installable on laptop
Gather information on Customers at trade show
Finished by May 13th, 2015




Bug Report:
This was built entirely on a tablet..  Using Windows 8.1.. Entity Framework likes a database server to be running when applying SQL.
THe localDB file gets overwritten every time.. Normally, I would have used an instance of SQL Server. 